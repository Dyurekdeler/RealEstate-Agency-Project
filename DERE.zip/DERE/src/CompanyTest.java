import java.text.ParseException;

import enigma.core.Enigma;



public class CompanyTest {

	public static void main(String[] args) throws ParseException {
		Enigma.getConsole("DERE", 80, 30, 12, 0);
		
		UserInterface ui = new UserInterface();
		
		ui.Interact();

	}

}
