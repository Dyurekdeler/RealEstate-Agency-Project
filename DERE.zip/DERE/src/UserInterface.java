
import java.util.Date;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class UserInterface {

	Company company = Company.getCompany();
	Scanner sc = new Scanner(System.in);
	Scanner sc2;
	Reader read = new Reader();

	public void Interact() throws ParseException {
		System.out.print("Welcome to DERE RealEstate Company!\nEnter a file name with load command: ");

		Boolean loadFlag = false;

		while (!loadFlag) {
			String firstcmd = sc.nextLine();
			String[] details = firstcmd.split(";");
			if (details[0].equals("load")) {

				try {
					File file = new File(details[1]);

					sc2 = new Scanner(file);
					loadFlag = true;
				} catch (FileNotFoundException e) {
					System.out.println("You entered invalid file name!");
				}
				if (loadFlag) {
					while (sc2.hasNextLine()) { // when a line is read, it's components splitted by ; and each component
												// added
												// to an array

						String line = sc2.nextLine();

						String[] cmddetails = line.split(";"); // splitting by semicolon ref :
						read.operations(cmddetails, line); // https://stackoverflow.com/questions/15903170/read-and-split-a-text-file-java

					}
				}

			}
		}
		System.out.println("You can enter your commands...(To exit please enter q letter)");
		String command="";
		while(!command.equals("q")) {
			command=sc.nextLine();
			String[] userCommand= command.split(";");
			read.operations(userCommand, command);
		}
		
		
		
		/////////////////////////

	}

}
