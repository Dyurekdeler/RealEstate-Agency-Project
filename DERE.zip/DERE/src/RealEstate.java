
public class RealEstate {
	private String estatetype, adress,  town,  city,status;
	private static int idCounter=0;
	private Boolean availability_status,searchFlag;
	private int numroom,id,surfacearea;
	private double price;
	
	
	public RealEstate(String estatetype, String status, String adress, String town, String city, int surfacearea,double price,int numroom,Boolean availability_status ) {
		idCounter++;
		this.id=idCounter;
		this.status=status;   // rent sale
		this.surfacearea=surfacearea;
		this.adress=adress;
		this.town=town;
		this.city=city;
		this.estatetype=estatetype;  //flat villa ..
		this.numroom=numroom;
		this.price=price;
		this.availability_status=availability_status;
		this.searchFlag=true;
	}
	public int getIdCounter() {
		return idCounter;
	}
	
	public String getEstatetype() {
		return estatetype;
	}

	public void setEstatetype(String estatetype) {
		this.estatetype = estatetype;
	}

	public int getSurfacearea() {
		return surfacearea;
	}

	public void setSurfacearea(int surfacearea) {
		this.surfacearea = surfacearea;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getAvailability_status() {
		return availability_status;
	}

	public void setAvailability_status(Boolean availability_status) {
		this.availability_status = availability_status;
	}

	public int getNumroom() {
		return numroom;
	}

	public void setNumroom(int numroom) {
		this.numroom = numroom;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	public Boolean getSearchFlag() {
		return searchFlag;
	}
	public void setSearchFlag(Boolean flag) {
		this.searchFlag=flag;
	}

	public String toString() {
		return " *** Real Estate "+id+" ***\nType: "+estatetype +"\n"+ status+"\n"+ "Adress : "+adress+"\n"+"Town : "+town+"\n"+ "City : "+city+"\n" +"Surface Area : "+surfacearea+"\n"+" Price : "+price+"\n"+
	"Number of Rooms : "+numroom+"\n---------------";
	}
}
