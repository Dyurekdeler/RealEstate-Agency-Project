
public class Agency {
	private int id;
	private static int idCounter=0;
	private String name, adress,  town,  city,phone;
	private double monthlyIncome;
	
	
	public Agency(String name, String adress, String town, String city, String phone ) {
		
		this.phone=phone;
		this.name=name;
		this.adress=adress;
		this.town=town;
		this.city=city;
		idCounter++;
		this.id=idCounter;
		monthlyIncome=0;
	}
	
	
	public int getIdCounter() {
		return idCounter;
	}


	public double getMontlyIncome() {
		return monthlyIncome;
	}

	public void setMontlyIncome(double montlyIncome) {
		this.monthlyIncome = montlyIncome;
	}
	public void addMonthlyIncome(double income) {
		this.monthlyIncome+=income;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		System.out.println("ID cannot be changed!s");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String toString() {
		return "Agency: "+getName()+"\nAdress: " +getAdress()+"\nTown: "+getTown()+"\nCity: "+getCity()+"\nPhone: "+getPhone()+"\n---------------";
	}
}
