
import java.util.Date;

public class Agent {
	private int id ,agencyid;
	private static int idCounter=0;
	private String name, adress,  town,  city, gender,phone;
	private Date bday;
	private Boolean status;
	private double salary,premium;
	private int numOfSales;
	
	
	public Agent(int agencyid,String name, Date bday, String adress, String town, String city, String phone , String gender,Boolean status) {
		idCounter++;
		this.id=idCounter;
		this.phone=phone;
		this.name=name;
		this.adress=adress;
		this.town=town;
		this.city=city;
		this.gender=gender;
		this.bday=bday;
		this.status=status;
		salary=2000;
		this.agencyid=agencyid;
		premium=0;
		numOfSales=0;
	}
	public int getIdCounter() {
		return idCounter;
	}
	public int getNumOfSales() {
		return numOfSales;
	}
	public void setNumOfSales(int numOfSales) {
		this.numOfSales=numOfSales;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	public void addPremium(double premium) {
		this.premium += premium;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id=id;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getAgencyid() {
		return agencyid;
	}

	public void setAgencyid(int agencyid) {
		this.agencyid = agencyid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBday() {
		return bday;
	}

	public void setBday(Date bday) {
		this.bday = bday;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String toString() {
		return "Name: "+getName()+"\nAdress: " +getAdress()+"\nTown: "+getTown()+"\nCity: "+getCity()+"\nPhone: "+getPhone()+"\n---------------";
	}
}
