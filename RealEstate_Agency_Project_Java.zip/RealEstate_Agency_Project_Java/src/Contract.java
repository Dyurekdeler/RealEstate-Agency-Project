import java.util.Date;

public class Contract {
	private Date contractdate;
	private static int idCounter=0;
	private int estateid, customerid,agentid, contractid;
	private int agencyid=0;
	
	public Contract(int estateid, int customerid, int agentid, Date contractdate) {
		
		this.estateid=estateid;
		this.customerid=customerid;
		this.agentid=agentid;
		this.contractdate=contractdate;
		idCounter++;
		this.contractid=idCounter;
		findAgency();
		
	}
	public static int getIdCounter() {
		return idCounter;
	}
	public static void decrementIdCounter() {
		idCounter--;
	}
	
	public void findAgency() {   //auto sets agencyid
		Company com = Company.getCompany();
		
		for(Agent a : com.getAgentlist()) {
			if(a!=null && getAgentid()==a.getId()) {
				setAgencyid(a.getAgencyid());
				
				break;
			}
		}
		
	}
	public int getAgencyid() {
		return agencyid;
	}
	public void setAgencyid(int agencyid) {
		this.agencyid=agencyid;
	}
	public Date getContractdate() {
		return contractdate;
	}

	public void setContractdate(Date contractdate) {
		this.contractdate = contractdate;
	}

	public int getEstateid() {
		return estateid;
	}

	public void setEstateid(int estateid) {
		this.estateid = estateid;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public int getAgentid() {
		return agentid;
	}

	public void setAgentid(int agentid) {
		this.agentid = agentid;
	}

	public int getContractid() {
		return contractid;
	}

	public void setContractid(int contractid) {
		this.contractid = contractid;
	}

	public String toString() {
		return " Contract id : "+contractid+" RealEstate id : "+estateid+" Customer id : "+customerid+ " Agent id: "+agentid+" Date : "+contractdate+"\n---------------";
	}
}
