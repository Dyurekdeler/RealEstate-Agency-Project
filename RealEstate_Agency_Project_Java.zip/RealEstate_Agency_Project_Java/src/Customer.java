import java.util.Date;

public class Customer {
	private int id;
	private static int idCounter=0;
	private String name, adress,  town,  city, gender,phone;
	private Date bday;
	private Boolean status;
	public Customer(String name, Date bday, String adress, String town, String city, String phone , String gender,Boolean status) {
		
		this.phone=phone;
		this.name=name;
		this.adress=adress;
		this.town=town;
		this.city=city;
		this.gender=gender;
		this.bday=bday;
		idCounter++;
		this.id=idCounter;
		this.status=status;
	}
	public int getIdCounter() {
		return idCounter;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Date getBday() {
		return bday;
	}
	public void setBday(Date bday) {
		this.bday = bday;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String toString() {
		return "Customer: "+getName()+"\nAdress: " +getAdress()+"\nTown: "+getTown()+"\nCity: "+getCity()+"\nPhone: "+getPhone()+"\n---------------";
	}
}
