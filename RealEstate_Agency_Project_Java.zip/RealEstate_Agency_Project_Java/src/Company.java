
import java.util.Date;

public class Company {

	private Agent[] agentlist = new Agent[100];
	private Agency[] agencylist = new Agency[100];
	private Customer[] customerlist = new Customer[100];
	private Contract[] contractlist = new Contract[100];
	private RealEstate[] realestatelist = new RealEstate[100];
	private double income;
	private static Company dere = null;

	public Company() {

		income = 0;
	}

	public static Company getCompany() { // in multiple classes, company is needed to be accessed to solve creating new
											// null compant obj. we return one company obj to all classes that need it.
		if (dere == null) { // if there is no company object ever created yet. create one and send it
			dere = new Company();
		}
		return dere;
	}

	public Agent[] getAgentlist() {
		return agentlist;
	}

	public Agency[] getAgencylist() {
		return agencylist;
	}

	public Customer[] getCustomerlist() {
		return customerlist;
	}

	public Contract[] getContractlist() {
		return contractlist;
	}

	public RealEstate[] getRealestatelist() {
		return realestatelist;
	}
	public void setIncome(double income) {
		this.income = income;
	}

	public double getIncome() {
		return income;
	}

	public void addIncome(double income) {
		this.income += income;
	}

	public void search(String type, String status, String town, String city, String surface, String price,
			String room) {
		int min_surface = 0, max_surface = 0;
		if (!surface.equals("")) {
			String[] surface_limit = surface.split("-");

			try {
				min_surface = Integer.parseInt(surface_limit[0]);
				max_surface = Integer.parseInt(surface_limit[1]);
			} catch (NumberFormatException e) {
				surface = ""; // in anyways do sth
			}
		}
		double min_price = 0, max_price = 0;
		if (!price.equals("")) {
			String[] price_limit = price.split("-");

			try {
				min_price = Double.parseDouble(price_limit[0]);
				max_price = Double.parseDouble(price_limit[1]);
			} catch (NumberFormatException e) {
				price = "";
			}
		}
		int min_room = 0, max_room = 0;
		String[] room_limit = null;
		if (!room.equals("")) {
			room_limit = room.split("-");
			try {
				min_room = Integer.parseInt(room_limit[0]);
				max_room = Integer.parseInt(room_limit[1]);
			} catch (NumberFormatException e) {
				room = "";
			}
		}
		for (RealEstate re : realestatelist) {
			if (re != null) {
				if (!type.equals("")) {
					if (!type.equals(re.getEstatetype())) {
						re.setSearchFlag(false);
						continue;
					}
				}
				if (!status.equals("")) {
					if (!status.equals(re.getStatus())) {
						re.setSearchFlag(false);
						continue;
					}
				}
				if (!town.equals("")) {
					if (!town.equals(re.getTown())) {
						re.setSearchFlag(false);
						continue;
					}
				}
				if (!city.equals("")) {
					if (!city.equals(re.getCity())) {
						re.setSearchFlag(false);
						continue;
					}
				}
				if (!surface.equals("")) {
					if (re.getSurfacearea() < min_surface || re.getSurfacearea() > max_surface) {
						re.setSearchFlag(false);
						continue;
					}
				}
				if (!price.equals("")) {
					if (re.getPrice() < min_price || re.getPrice() > max_price) {
						re.setSearchFlag(false);
						continue;
					}
				}
				if (!room.equals("")) {
					if (re.getNumroom() < min_room || re.getNumroom() > max_room) {
						re.setSearchFlag(false);
						continue;
					}
				}
			}
		}
		System.out.println("**************************");
		System.out.println("Search List");
		for (RealEstate re : realestatelist) {
			if (re != null && re.getSearchFlag() && re.getAvailability_status()) {
				System.out.println(re.toString());
			}
		}
		System.out.println("**************************");
		for (RealEstate re : realestatelist) {
			if (re != null)
				re.setSearchFlag(true);
		}

	}


	public void addAgent(Agent a) {
		for(Agency agency: agencylist) {
			if(agency!=null && a.getAgencyid()==agency.getId() && agency.getCity().equals(a.getCity())) {
				for (int i = 0; i < agentlist.length; i++) {
					if (agentlist[i] == null) {
						agentlist[i] = a;
						System.out.println("Agent is added to " +agency.getName()+" agency...");
						break;
					}
				}
				break;
			}
		}
		
	}

	public void addAgency(Agency a) {
		for (int i = 0; i < agencylist.length; i++) {
			if (agencylist[i] == null) {
				agencylist[i] = a;
				break;
			}
		}
	}

	public void addContract(Contract c) {
		Boolean isEstateFound = false;
		Boolean isAgentFound = false;
		Boolean isCusFound = false;
		RealEstate estate = null;
		for (Customer cus : customerlist) {
			if (cus != null && cus.getStatus()&& cus.getId() == c.getCustomerid()) {
				isCusFound = true;
				break;
			}
		}
		if (isCusFound) {
			for (RealEstate re : realestatelist) {
				if (re != null && re.getId() == c.getEstateid() && re.getAvailability_status()) {
					estate = re;
					re.setAvailability_status(false); // set avaibility false means it is sold/rented
					isEstateFound = true;
					break;
				}

			}
		}
		else {
			System.out.println("There is no such a customer in the list!");
			Contract.decrementIdCounter();
			return;
			
		}
		if (isEstateFound) {
			for (Agent agent : agentlist) {
				if (agent != null && agent.getStatus() && c.getAgentid() == agent.getId() && agent.getCity().equals(estate.getCity())) {
					isAgentFound = true;
					for (int i = 0; i < contractlist.length; i++) {
						if (contractlist[i] == null) {
							contractlist[i] = c;
							break;
						}
					}
					break;
				}
			}
			if (!isAgentFound) {
				System.out.println("Agent is not found in the real estate's city");
				Contract.decrementIdCounter();
				return;
			}		
		}
		else {
			System.out.println("Error occured while adding a contract. There is no such Real Estate exists!");
			Contract.decrementIdCounter();
		
		}	
	}

	public void addCustomer(Customer c) {
		for (int i = 0; i < customerlist.length; i++) {
			if (customerlist[i] == null) {
				customerlist[i] = c;
				break;
			}
		}
	}

	public void addRealEstate(RealEstate re) {
		for (int i = 0; i < realestatelist.length; i++) {
			if (realestatelist[i] == null) {
				realestatelist[i] = re;
				break;
			}
		}
	}

	public void removeAgent(int id) {
		Agent a = null; // to print error message
		for (Agent agent : agentlist) {
			if (agent != null && id == agent.getId() && agent.getStatus()) {
				a = agent;
				a.setStatus(false);
				break;
			}
		}
		if (a != null)
			System.out.println("Succesfully removed " + a.getName());
		else
			System.out.println("Agent is not found");

	}

	public void removeCustomer(int id) {
		Customer c = null;
		for (Customer customer : customerlist) {
			if (customer != null && id == customer.getId() && customer.getStatus()) {
				c = customer;
				c.setStatus(false);
				break;
			}
		}
		if (c != null)
			System.out.println("Succesfully removed " + c.getName());
		else
			System.out.println("Customer is not found");

	}

	public void removeRealEstate(int id) {
		RealEstate re = null;
		for (RealEstate realestate : realestatelist) {
			if (realestate != null && id == realestate.getId() && realestate.getAvailability_status()) {
				re = realestate;
				re.setAvailability_status(false);
				break;
			}
		}
		if (re != null)
			System.out.println("Succesfully removed " + re.getId());
		else
			System.out.println("RealEstate is not found");
	}

	public void display(String type) {

		if (type.equals("Agency")) {
			System.out.println("*** Agency List ***");
			for (Agency a : agencylist) {
				if (a != null)
					System.out.println(a.toString());
			}
		} else if (type.equals("Agent")) {
			System.out.println("*** Agent List ***");
			for (Agent a : agentlist) {
				if (a != null && a.getStatus())
					System.out.println(a.toString());
			}
		} else if (type.equals("Customer")) {
			System.out.println("*** Customer List ***");
			for (Customer a : customerlist) {
				if (a != null && a.getStatus())
					System.out.println(a.toString());
			}
		} else if (type.equals("RealEstate")) {
			System.out.println("*** RealEstate List ***");
			for (RealEstate a : realestatelist) {
				if (a != null && a.getAvailability_status())
					System.out.println(a.toString());
			}
		} else if (type.equals("Contract")) {
			System.out.println("*** Contract List ***");
			for (Contract a : contractlist) {
				if (a != null)
					System.out.println(a.toString());
			}
		}
	}

	public void calculateSalaries(Date date) {

		for (Contract contract : contractlist) {
			if (contract != null && contract.getContractdate().getMonth() == date.getMonth()
					&& contract.getContractdate().getYear() == date.getYear()) {
				for (Agent agent : agentlist) {
					if (agent != null && contract.getAgentid() == agent.getId()) {

						for (RealEstate re : realestatelist) {
							if (re != null && re.getId() == contract.getEstateid()) {

								if (re.getStatus().equals("For Sale"))
									agent.addPremium(re.getPrice() * 0.05);
								else
									agent.addPremium(re.getPrice() * 0.2);
								break;
							}
						}
						break;
					}
				}

			}
		}
		System.out.println("*******************************");
		System.out.println("Salaries of all Agents");
		for (Agent a : agentlist) {
			if (a != null) {
				System.out.println("Agent\n" + a + "\nSalary: " + (a.getSalary() + a.getPremium()));
				a.setPremium(0);
				System.out.println();
			}
		}
		System.out.println("*******************************");
	}

	public void calculateTotalIncome(Date date) {
		for (Contract con : contractlist) {
			if (con != null && con.getContractdate().getMonth() == date.getMonth()
					&& con.getContractdate().getYear() == date.getYear()) {

				for (RealEstate re : realestatelist) {

					if (re != null && re.getId() == con.getEstateid()) {
						if (re.getStatus().equals("For Sale"))
							addIncome(re.getPrice() * 0.15);
						else
							addIncome(re.getPrice() * 0.8);
						break;
					}

				}
			}
		}

		System.out.println("Total Income of the DERE :" + getIncome());
		setIncome(0);
	}

	public void mostProfitableAgency(Date date) {

		for (Contract con : contractlist) {
			if (con != null && con.getContractdate().getMonth() == date.getMonth()
					&& con.getContractdate().getYear() == date.getYear()) {
				for (RealEstate re : realestatelist) {
					if (re != null && re.getId() == con.getEstateid()) {
						for (Agency a : agencylist) {
							if (a != null && con.getAgencyid() == a.getId()) {
								if (re.getStatus().equals("For Sale"))
									a.addMonthlyIncome(re.getPrice() * 0.15);
								else
									a.addMonthlyIncome(re.getPrice() * 0.8);
								
								break;
							}
							
						}
						break;
					}

				}
			}
		}
		double max = 0;
		Agency amax = null;
		for (Agency agency : agencylist) {
			if (agency != null && agency.getMontlyIncome() > max) {
				max = agency.getMontlyIncome();
				amax = agency;
			}
		}
		System.out.println("Most profitable agency of the month is : " + amax.getName() + " Income : " + max);
		for (Agency agency : agencylist) {
			if (agency != null)
				agency.setMontlyIncome(0);
		}
	}

	public void agentOfTheMonth(Date date) {
		for (Contract c : contractlist) {
			if (c != null && c.getContractdate().getMonth() == date.getMonth()
					&& c.getContractdate().getYear() == date.getYear()) {
				for (Agent a : agentlist) {
					if (a != null && a.getId() == c.getAgentid()) {
						a.setNumOfSales(a.getNumOfSales() + 1);
					}
				}
			}
		}
		int maxSales = 0;
		Agent agentOfTheMonth = null;
		for (Agent a : agentlist) {
			if (a != null && a.getNumOfSales() > maxSales) {
				maxSales = a.getNumOfSales();
				agentOfTheMonth = a;
			}
		}

		System.out.println("Agent of the Month: " + agentOfTheMonth.getName() + " with "
				+ agentOfTheMonth.getNumOfSales() + " sales");
		for (Agent a : agentlist) {
			if (a != null)
				a.setNumOfSales(0);
		}
	}

}