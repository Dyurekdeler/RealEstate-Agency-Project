
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Reader {

	Company rec = Company.getCompany(); // fetching same company object

	
	public void operations(String[] details,String originaltext) throws ParseException {
		String type = details[0];
		if (type.equals("addAgent")) {

			// system auto id each agent ( starts from 1 )
			int agencyid = Integer.parseInt(details[1]);
			String agentname = details[2];
			Date bday = new SimpleDateFormat("dd/MM/yyyy").parse(details[3]); // reference :
																				// https://www.javatpoint.com/java-string-to-date
			String adress = details[4];
			String town = details[5];
			String city = details[6];
			String phone = details[7];
			String gender = details[8];
			Boolean status = true;

			Agent agent = new Agent(agencyid, agentname, bday, adress, town, city, phone, gender, status);
			rec.addAgent(agent);

		}

		else if (type.equals("addAgency")) {

			String agencyname = details[1];
			String adress = details[2];
			String town = details[3];
			String city = details[4];
			String phone = details[5];
			
			Agency agency = new Agency(agencyname, adress, town, city, phone);
			rec.addAgency(agency);

		} else if (type.equals("addRealEstate")) {

			/// BURADA STATUS OKUNACAK MI YOKSA OTO. TRUE MU ATANACAK ?????????????
			String typeestate = details[1];
			String status = details[2]; // ref : http://www.java67.com/2018/03/java-convert-string-to-boolean.html
			String adress = details[3];
			String town = details[4];
			String city = details[5];
			int surfacearea = Integer.parseInt(details[6]);
			double price = Double.parseDouble(details[7]); // ref :
															// http://www.java67.com/2015/06/how-to-convert-string-to-double-java-example.html
			int numofrooms = Integer.parseInt(details[8]); // ref :
															// https://www.mkyong.com/java/java-convert-string-to-int/
			// system auto id each realestate ( starts from 1 )
			Boolean availability = true;

			RealEstate realestate = new RealEstate(typeestate, status, adress, town, city, surfacearea, price,
					numofrooms, availability);
			rec.addRealEstate(realestate);

		}

		else if (type.equals("addCustomer")) {

			String name = details[1];
			Date bday = new SimpleDateFormat("dd/MM/yyyy").parse(details[2]); // reference :																			// https://www.javatpoint.com/java-string-to-date
			String adress = details[3];
			String town = details[4];
			String city = details[5];
			String phone = details[6];
			String gender = details[7];
			Boolean status = true;
			Customer customer = new Customer(name, bday, adress, town, city, phone, gender, status);
			rec.addCustomer(customer);

		} else if (type.equals("search")) {

			String[] detailswithblank = new String[8];
			String typeestate;
			String status;
			String town;
			String city;
			String surfacearea;
			String price;
			String numofrooms;
				if (originaltext.contains(";;")) { // means some parts are left blank
				detailswithblank = originaltext.split(";", -1);
				typeestate = detailswithblank[1];
				status = detailswithblank[2];
				town = detailswithblank[3];
				city = detailswithblank[4];
				surfacearea = detailswithblank[5];
				price = detailswithblank[6];
				numofrooms = detailswithblank[7];
			} else {
				typeestate = details[1];
				status = details[2];
				town = details[3];
				city = details[4];
				surfacearea = details[5];
				price = details[6];
				numofrooms = details[7];
			}
				
				rec.search(typeestate, status, town, city, surfacearea, price, numofrooms);
		}
		
			
		 else if (type.equals("addContract")) {

			int realestateid = Integer.parseInt(details[1]);
			int customerid = Integer.parseInt(details[2]);
			int agentid = Integer.parseInt(details[3]);
			Date contractdate = new SimpleDateFormat("dd/MM/yyyy").parse(details[4]); // reference :
																						// https://www.javatpoint.com/java-string-to-date

			Contract contract = new Contract(realestateid, customerid, agentid, contractdate);
			rec.addContract(contract);

		}

		else if (type.equals("displayAgencies")) {
			rec.display("Agency");
		} else if (type.equals("displayAgents")) {
			rec.display("Agent");
		} else if (type.equals("displayRealEstates")) {
			rec.display("RealEstate");
		} else if (type.equals("displayCustomers")) {
			rec.display("Customer");
		} else if (type.equals("displayContracts")) {
			rec.display("Contract");
		}

		else if (type.equals("deleteAgent")) {

			rec.removeAgent(Integer.parseInt(details[1]));
		}

		else if (type.equals("deleteRealEstate")) {

			rec.removeRealEstate(Integer.parseInt(details[1]));
		} else if (type.equals("deleteCustomer")) {

			rec.removeCustomer(Integer.parseInt(details[1]));
		}

		else if (type.equals("calculateSalaries")) {
			rec.calculateSalaries(new SimpleDateFormat("MM/yyyy").parse(details[1]));
		} else if (type.equals("agentOfTheMonth")) {
			rec.agentOfTheMonth(new SimpleDateFormat("MM/yyyy").parse(details[1]));
		} else if (type.equals("calculateTotalIncome")) {
			rec.calculateTotalIncome(new SimpleDateFormat("MM/yyyy").parse(details[1]));
		} else if (type.equals("mostProfitableAgency")) {
			rec.mostProfitableAgency(new SimpleDateFormat("MM/yyyy").parse(details[1]));
		}

	}

	
}
